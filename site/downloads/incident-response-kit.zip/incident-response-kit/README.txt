AFTER THE ALERT — FREE INCIDENT RESPONSE KIT
Snapshot: 22 October 2026
Website: https://after-the-alert.pages.dev/

START HERE
1. Open the matching Markdown playbook in playbooks/. It contains applicability,
   immediate actions, recovery steps, verification and original-source links.
2. Recheck the current vendor notice. These files are a dated snapshot.
3. Assign the technical owner. Preserve evidence while coordinating containment.
4. Use templates/ to record assets, credential aliases and migration acceptance.
   Keep completed records private. Never put secret values in a worksheet.
5. Read a script before running it. Use a trusted environment and an offline,
   read-only copy of suspect files. No script in this kit patches a system.

TOOLS (run from the kit's root directory)
node tools/check-php-version.mjs 8.3.35
node tools/inspect-dependency-files.mjs --json -- /path/to/requirements.txt
bash tools/inspect-litellm-metadata.sh /physical/path/to/site-packages

Node.js tools use only the standard library; Bash tool uses builtins. No packages
need installing. Do not invoke Python or pip in a potentially affected LiteLLM
environment. Dependency declarations are not installation/execution evidence.
The metadata tool checks immediate entries, rejects symlink paths and reads no
file contents. The dependency parser is conservative, not a complete TOML/YAML
parser. UNKNOWN is unresolved, never clearance. Read each tool's --help.

Exit 0 means a check/processing step completed, not that a host is safe.
Exit 2 indicates invalid, rejected or unassessed input. Preserve the output.

REUSE
Original guides and scripts are free to use and redistribute. Third-party source
materials retain their owners' rights. No vendor endorsement is implied.
Optional donations: native USDC on Base only.
0x356a4E9BFAC16828103FDE83407dCe4e5ea947f5
Donations unlock nothing and do not buy incident-response support.

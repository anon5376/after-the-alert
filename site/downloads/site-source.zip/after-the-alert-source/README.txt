AFTER THE ALERT — WEBSITE SOURCE
Static HTML/CSS/JS. No application dependencies.
Run tests: node --test tests/*.test.mjs
Rebuild pages: node scripts/build-site.mjs
Package downloads (macOS zip path): node scripts/package.mjs
Serve site/ with a static HTTP server to use the browser modules.
All user-entered tool data stays in the browser tab unless the user exports it.
Only publish site/. Keep credentials outside this tree.
Original code and guides are free to use and redistribute. Third-party source
materials retain their owners' rights. IBM Plex Sans is distributed under the SIL Open Font License in
site/assets/OFL-IBM-Plex-Sans.txt.
ZIP downloads are omitted from this source archive to avoid recursive copies.
